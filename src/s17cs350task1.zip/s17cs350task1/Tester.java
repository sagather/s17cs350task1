package s17cs350task1;

import javafx.geometry.Point3D;

/**
 * Created by bcxtr on 4/10/2017.
 */
public class Tester {

    public static void main(String[] args){

        /*Box box1 = new Box("box1", new Dimension3D(3,5), true);
        Box box2 = new Box("box2", new Dimension3D(4,6));
        Box box3 = new Box("box3", new Dimension3D(8,7));
        Box box4 = new Box("box4", new Dimension3D(2,5));
        Box box5 = new Box("box4", new Dimension3D(3, 3));
        Box box6 = new Box("box6", null);
        //Box box6 = new Box("box6", new Dimension3D(-3, 3, 9)); //checks negative dimensions

        box1.connectChild(new Connector(box2, new Point3D(10,12,0)));
        box2.connectChild(new Connector(box3, new Point3D(-2, -15,0)));
        box2.connectChild(new Connector(box4, new Point3D(7, -8,0)));
        //box1.connectChild(new Connector(box3, new Point3D(3,3,3))); //checks for parent already existing
        //box4.connectChild(new Connector(box1, new Point3D(2, 2,2))); //checks for same name

        System.out.println(box1);
        for(Box b : box1.getDescendantBoxes()){
            System.out.println(b.toString());
        }

        try{
            Box cBox = box1.clone();
            System.out.println(cBox);
            for(Box b : cBox.getDescendantBoxes()){
                System.out.println(b.toString());
            }
        }catch (CloneNotSupportedException e){
            System.out.println(e.getStackTrace());
        }

        System.out.println(box4.getAbsoluteCenterPosition());
        System.out.println(box2.getSize()); */

        Tester2 tester = new Tester2();
        tester.runTests();
        tester.printResults();

    }


}
